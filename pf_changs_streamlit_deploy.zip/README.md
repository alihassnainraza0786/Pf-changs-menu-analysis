# P.F. Chang's Menu Analysis — Streamlit App

This project converts the supplied Google Colab notebook into a Streamlit web app.

## Files
- `app.py` — Streamlit application (dataset, filters, charts, drink keyword classification)
- `requirements.txt` — Python dependencies
- `pf_changs_desserts_beverages.csv` — sample dataset from the notebook

## Run locally
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start Streamlit:
   ```bash
   streamlit run app.py
   ```
5. Open the local URL shown in the terminal (usually http://localhost:8501).

## Deploy on Streamlit Community Cloud
1. Sign in to GitHub and create a **public** repository (or a private repository you can connect).
2. Upload `app.py`, `requirements.txt`, and `pf_changs_desserts_beverages.csv` to the repository root.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Click **Create app**.
5. Select your repository, branch (usually `main`), and main file path `app.py`.
6. Click **Deploy**. Wait for the build to finish.
7. Open the generated app URL to test and share it.

## Important project note
The original notebook tries to scrape P.F. Chang's website. Website scraping can fail when a site blocks automated requests or changes its HTML. To make the deployed app reliable, this version starts with the fallback sample dataset from your notebook. Users can upload another CSV from the sidebar.

The classifier reproduces the notebook's keyword-based rule. It is a simple rule, not a trained ML model, so its displayed accuracy applies only to the 10 examples included in the notebook.
